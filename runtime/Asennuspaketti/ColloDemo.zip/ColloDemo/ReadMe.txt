Asennat t�m�n Demo-softan t�ysin omalla vastuullasi.
Mit��n takuita toimivuudesta ei my�nnet� ja kaikki oikeudet pid�tet��n
Ongelma tapauksissa voit ottaa yhteytt� ColloidTekin asiakaspalveluun s�hk�postilla
osoitteeseen roskapostia@colloidtek.fi

Asennusohjeet:

1. Poista vanha versiot siit� Demosta jota olet asentamassa
2. Pura ColloDemo.zip tiedosto
3. Asenna puretussa hakemistossa oleva .exe-tiedosto
	- Jos koneella ei ole ennest��n Matlabin Runtime-ohjelmistoa se asennetaan
	  samalla
4. Aja puretussa hakemistossa oleva "ColloDemoSetup.bat"-tiedosto
5. Voit halutessasi poistaa puretun kansion ja zip-tiedoston



